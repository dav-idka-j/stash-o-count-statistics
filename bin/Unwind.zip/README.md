# Unwind StashApp Plugin

This repository contains the **Unwind** plugin for the organizer [Stash](https://stashapp.cc/). It provides a "year in review" summary of your Stash activity.

This plugin requires the **StashGraphs** plugin to render charts.
